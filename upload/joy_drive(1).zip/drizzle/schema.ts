import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "driver"]).default("user").notNull(),
  photoUrl: text("photoUrl"),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
  ratingCount: int("ratingCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Drivers table
 */
export const drivers = mysqlTable("drivers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  licenseNumber: varchar("licenseNumber", { length: 50 }).notNull(),
  licenseExpiry: timestamp("licenseExpiry").notNull(),
  bankAccount: varchar("bankAccount", { length: 100 }).notNull(),
  isVerified: int("isVerified").default(0).notNull(),
  status: mysqlEnum("status", ["offline", "online", "on_ride", "break"]).default("offline").notNull(),
  currentLocation: json("currentLocation"),
  totalRides: int("totalRides").default(0),
  totalEarnings: decimal("totalEarnings", { precision: 12, scale: 2 }).default("0"),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
  ratingCount: int("ratingCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("driver_userId_idx").on(table.userId),
}));

export type Driver = typeof drivers.$inferSelect;
export type InsertDriver = typeof drivers.$inferInsert;

/**
 * Vehicles table
 */
export const vehicles = mysqlTable("vehicles", {
  id: int("id").autoincrement().primaryKey(),
  driverId: int("driverId").notNull(),
  type: mysqlEnum("type", ["Lite", "Drive", "VIP"]).notNull(),
  licensePlate: varchar("licensePlate", { length: 20 }).notNull(),
  color: varchar("color", { length: 50 }),
  capacity: int("capacity").default(4),
  make: varchar("make", { length: 100 }),
  model: varchar("model", { length: 100 }),
  year: int("year"),
  photoUrl: text("photoUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  driverIdIdx: index("vehicle_driverId_idx").on(table.driverId),
}));

export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = typeof vehicles.$inferInsert;

/**
 * Rides/Courses
 */
export const rides = mysqlTable("rides", {
  id: int("id").autoincrement().primaryKey(),
  passengerId: int("passengerId").notNull(),
  driverId: int("driverId"),
  vehicleId: int("vehicleId"),
  vehicleType: mysqlEnum("vehicleType", ["Lite", "Drive", "VIP"]).notNull(),
  pickupLocation: json("pickupLocation").notNull(),
  dropoffLocation: json("dropoffLocation").notNull(),
  stops: json("stops"),
  estimatedDistance: decimal("estimatedDistance", { precision: 8, scale: 2 }),
  estimatedDuration: int("estimatedDuration"),
  baseFare: decimal("baseFare", { precision: 8, scale: 2 }).notNull(),
  distanceFare: decimal("distanceFare", { precision: 8, scale: 2 }).default("0"),
  timeFare: decimal("timeFare", { precision: 8, scale: 2 }).default("0"),
  totalFare: decimal("totalFare", { precision: 8, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["requested", "accepted", "driver_arriving", "in_progress", "completed", "cancelled"]).default("requested").notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["card", "cash"]).default("card").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "completed", "failed", "refunded"]).default("pending").notNull(),
  requestedAt: timestamp("requestedAt").defaultNow().notNull(),
  acceptedAt: timestamp("acceptedAt"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  cancelledAt: timestamp("cancelledAt"),
  cancellationReason: text("cancellationReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  passengerIdIdx: index("ride_passengerId_idx").on(table.passengerId),
  driverIdIdx: index("ride_driverId_idx").on(table.driverId),
  statusIdx: index("ride_status_idx").on(table.status),
  vehicleTypeIdx: index("ride_vehicleType_idx").on(table.vehicleType),
}));

export type Ride = typeof rides.$inferSelect;
export type InsertRide = typeof rides.$inferInsert;

/**
 * Payments
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  rideId: int("rideId").notNull(),
  passengerId: int("passengerId").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  method: mysqlEnum("method", ["card", "cash"]).default("card").notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"]).default("pending").notNull(),
  stripePaymentId: varchar("stripePaymentId", { length: 100 }),
  stripeIntentId: varchar("stripeIntentId", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  rideIdIdx: index("payment_rideId_idx").on(table.rideId),
  passengerIdIdx: index("payment_passengerId_idx").on(table.passengerId),
}));

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * Notifications
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  rideId: int("rideId"),
  isRead: int("isRead").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("notification_userId_idx").on(table.userId),
}));

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Ratings
 */
export const ratings = mysqlTable("ratings", {
  id: int("id").autoincrement().primaryKey(),
  fromUserId: int("fromUserId").notNull(),
  toUserId: int("toUserId").notNull(),
  rideId: int("rideId").notNull(),
  score: int("score").notNull(),
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  fromUserIdIdx: index("rating_fromUserId_idx").on(table.fromUserId),
  toUserIdIdx: index("rating_toUserId_idx").on(table.toUserId),
  rideIdIdx: index("rating_rideId_idx").on(table.rideId),
}));

export type Rating = typeof ratings.$inferSelect;
export type InsertRating = typeof ratings.$inferInsert;

/**
 * Files (for photos and documents)
 */
export const files = mysqlTable("files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["profile_photo", "document", "vehicle_photo"]).notNull(),
  fileKey: varchar("fileKey", { length: 255 }).notNull(),
  url: text("url").notNull(),
  mimeType: varchar("mimeType", { length: 50 }),
  size: int("size"),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("file_userId_idx").on(table.userId),
}));

export type File = typeof files.$inferSelect;
export type InsertFile = typeof files.$inferInsert;

/**
 * Voice Messages
 */
export const voiceMessages = mysqlTable("voiceMessages", {
  id: int("id").autoincrement().primaryKey(),
  rideId: int("rideId").notNull(),
  fromUserId: int("fromUserId").notNull(),
  toUserId: int("toUserId").notNull(),
  audioUrl: text("audioUrl").notNull(),
  transcription: text("transcription"),
  duration: int("duration"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  rideIdIdx: index("voiceMessage_rideId_idx").on(table.rideId),
}));

export type VoiceMessage = typeof voiceMessages.$inferSelect;
export type InsertVoiceMessage = typeof voiceMessages.$inferInsert;

/**
 * Ride History
 */
export const rideHistory = mysqlTable("rideHistory", {
  id: int("id").autoincrement().primaryKey(),
  rideId: int("rideId").notNull(),
  passengerId: int("passengerId").notNull(),
  driverId: int("driverId").notNull(),
  fromLocation: varchar("fromLocation", { length: 255 }).notNull(),
  toLocation: varchar("toLocation", { length: 255 }).notNull(),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  rideType: mysqlEnum("rideType", ["Lite", "Drive", "VIP"]).notNull(),
  distance: decimal("distance", { precision: 8, scale: 2 }),
  duration: int("duration"),
  completedAt: timestamp("completedAt").notNull(),
}, (table) => ({
  passengerIdIdx: index("rideHistory_passengerId_idx").on(table.passengerId),
  driverIdIdx: index("rideHistory_driverId_idx").on(table.driverId),
}));

export type RideHistory = typeof rideHistory.$inferSelect;
export type InsertRideHistory = typeof rideHistory.$inferInsert;
